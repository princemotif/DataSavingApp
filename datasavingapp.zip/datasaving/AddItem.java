package com.example.datasaving;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class AddItem extends AppCompatActivity implements View.OnClickListener {


    EditText editTextCustomername,editTextDesktop,editTextProblem,editTextActiontaken,editTextApproval,editTextPaid,editTextDelivery;
    Button buttonAddItem;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.add_item);

        editTextCustomername = (EditText)findViewById(R.id.et_item_name);
        editTextDesktop = (EditText)findViewById(R.id.et_Desktop);
        editTextProblem = (EditText)findViewById(R.id.et_Problem);
        editTextActiontaken = (EditText)findViewById(R.id.et_Actiontaken);
        editTextApproval = (EditText)findViewById(R.id.et_Approval);
        editTextPaid = (EditText)findViewById(R.id.et_Paid);
        editTextDelivery = (EditText)findViewById(R.id.et_Delivery);

        buttonAddItem = (Button)findViewById(R.id.btn_add_item);
        buttonAddItem.setOnClickListener(this);


    }

    //This is the part where data is transafeered from Your Android phone to Sheet by using HTTP Rest API calls

    private void   addItemToSheet() {

        final ProgressDialog loading = ProgressDialog.show(this,"Adding Item","Please wait");
        final String name = editTextCustomername.getText().toString().trim();
        final String desktop = editTextDesktop.getText().toString().trim();
        final String problem = editTextProblem.getText().toString().trim();
        final String actiontaken = editTextActiontaken.getText().toString().trim();
        final String approval = editTextApproval.getText().toString().trim();
        final String paid = editTextPaid.getText().toString().trim();
        final String delivery = editTextDelivery.getText().toString().trim();




        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://script.google.com/macros/s/AKfycbw7sGWo7crf7r_1qM16raKquITpthhUbn6X6ngs5AREynRz_veReHFAqhDtxhTpFhW5/exec",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        loading.dismiss();
                        Toast.makeText(AddItem.this,response,Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(intent);

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> parmas = new HashMap<>();

                //here we pass params
                parmas.put("action","addItem");
                parmas.put("custName",name);
                parmas.put("desktop",desktop);
                parmas.put("problem",problem);
                parmas.put("actiontaken",actiontaken);
                parmas.put("approval",approval);
                parmas.put("paid",paid);
                parmas.put("delivery",delivery);

                return parmas;
            }
        };

        int socketTimeOut = 50000;// u can change this .. here it is 50 seconds

        RetryPolicy retryPolicy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(retryPolicy);

        RequestQueue queue = Volley.newRequestQueue(this);

        queue.add(stringRequest);


    }




    @Override
    public void onClick(View v) {

        if(v==buttonAddItem){
            addItemToSheet();

            //Define what to do when button is clicked
        }
    }
}

