package com.example.datasaving;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ItemDetails extends AppCompatActivity  {


    TextView textViewcustName, textViewDesktop, textViewProblem,textViewNo,textViewAction,textViewApproval,textViewPaid,textViewDelivery;
    Button buttonUpdateItem, buttonDeleteItem;
    String job, custName, desktop, problem, action, approval, paid, delivery;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.item_details);

        Intent intent = getIntent();
        job = intent.getStringExtra("job");
        custName = intent.getStringExtra("custName");
        desktop = intent.getStringExtra("desktop");
        problem = intent.getStringExtra("problem");
        action = intent.getStringExtra("action");
        approval = intent.getStringExtra("approval");
        paid = intent.getStringExtra("paid");
        delivery = intent.getStringExtra("delivery");

        textViewNo = (TextView)findViewById(R.id.tv_id);
        textViewcustName = (TextView) findViewById(R.id.tv_item_name);
        textViewDesktop = (TextView) findViewById(R.id.tv_brand);
        textViewProblem = (TextView) findViewById(R.id.tv_price);
        textViewAction = (TextView) findViewById(R.id.tv_action);
        textViewApproval = (TextView) findViewById(R.id.tv_approval);
        textViewPaid = (TextView) findViewById(R.id.tv_paid);
        textViewDelivery = (TextView) findViewById(R.id.tv_delivery);

        textViewNo.setText(job);
        textViewcustName.setText(custName);
        textViewDesktop.setText(desktop);
        textViewProblem.setText(problem);
        textViewAction.setText(action);
        textViewApproval.setText(approval);
        textViewPaid.setText(paid);
        textViewDelivery.setText(delivery);


    }
}
